## usage :
		NOTE :::::: this file is create with hbase.2.1.1 the other version maybe not work ...
	Step1: change the url
		the default url is http://m6.bigdata.lyjt.360es.cn:16010
		if you want to change the url please edit run.bat and change the default url to yours
	Step2: double click run.bat to run this program
	Step3: find the result
		the result will be found in the scrapy.result file